BusGo - Java Swing Bus Ticket Booking (Eclipse + MySQL)

SETUP
1. MySQL Workbench: open database_setup.sql and run it (creates database "busbooking", tables, sample buses, admin).
   Change the sample bus dates to future dates.
2. Eclipse: File > New > Java Project (any name). Right-click src > New > Package "busbooking".
   Copy all .java files from src/busbooking and paste onto that package.
3. Add MySQL connector jar: right-click project > Build Path > Configure Build Path > Libraries > Classpath > Add External JARs.
4. Open DBConnection.java and set USER and PASS to your own MySQL login (default: root / root).
5. Run Main.java (Run As > Java Application).

LOGINS
Admin: admin / admin123
Passenger: use "Create Passenger Account"
