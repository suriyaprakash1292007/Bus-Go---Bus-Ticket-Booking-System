-- ============ BusGo : complete MySQL setup (run once in MySQL Workbench) ============
CREATE DATABASE IF NOT EXISTS busbooking;
USE busbooking;

CREATE TABLE IF NOT EXISTS users (
  user_id   INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email     VARCHAR(100) NOT NULL,
  phone     VARCHAR(15)  NOT NULL,
  username  VARCHAR(50)  NOT NULL UNIQUE,
  password  VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50)  NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS buses (
  bus_id           INT AUTO_INCREMENT PRIMARY KEY,
  bus_name         VARCHAR(100) NOT NULL,
  bus_number       VARCHAR(30)  NOT NULL,
  source_city      VARCHAR(60)  NOT NULL,
  destination_city VARCHAR(60)  NOT NULL,
  departure_time   VARCHAR(20)  NOT NULL,
  arrival_time     VARCHAR(20)  NOT NULL,
  journey_date     DATE         NOT NULL,
  fare             DECIMAL(10,2) NOT NULL,
  total_seats      INT NOT NULL,
  available_seats  INT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
  booking_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  bus_id       INT NOT NULL,
  seats        INT NOT NULL,                       -- number of seats (used by cancellation)
  seat_numbers VARCHAR(255),                       -- e.g. 5,6,11  (used by seat map)
  total_fare   DECIMAL(10,2) NOT NULL,
  status       VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
  booked_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (bus_id)  REFERENCES buses(bus_id)
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount     DECIMAL(10,2) NOT NULL,
  method     VARCHAR(20) NOT NULL,                 -- UPI / CARD / NETBANKING
  txn_ref    VARCHAR(30) NOT NULL,
  paid_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- sample data (change dates to future dates)
INSERT INTO admins(username,password) VALUES ('admin','admin123');
INSERT INTO buses(bus_name,bus_number,source_city,destination_city,departure_time,arrival_time,journey_date,fare,total_seats,available_seats) VALUES
('SRS Travels','TN58 AB 1234','Madurai','Chennai','21:00','05:00','2026-12-20',650,40,40),
('KPN Travels','TN72 CD 5678','Madurai','Bangalore','20:30','06:00','2026-12-20',850,36,36),
('Parveen Travels','TN01 EF 9012','Chennai','Madurai','22:00','06:00','2026-12-21',700,40,40);

-- If you ALREADY have the old tables, run only this instead of the whole file:
-- ALTER TABLE bookings ADD COLUMN seat_numbers VARCHAR(255) NULL;
-- then create the payments table above.
