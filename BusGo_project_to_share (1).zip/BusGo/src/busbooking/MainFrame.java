package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("BusGo | Bus Ticket Booking");
        setSize(980, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        add(UI.hero("Travel made simple.", "Find your route. Choose your seat. Pay securely. Enjoy the journey."));

        JPanel right = UI.white();
        right.setBorder(new EmptyBorder(70, 80, 60, 80));
        right.add(UI.h1("Welcome"));
        right.add(Box.createVerticalStrut(4));
        right.add(UI.muted("Login or create an account to book your bus"));
        right.add(Box.createVerticalStrut(30));
        JButton l = new JButton("Passenger Login");
        JButton r = UI.ghost(new JButton("Create Passenger Account"));
        JButton a = UI.ghost(new JButton("Admin Login"));
        JButton x = UI.danger(new JButton("Exit Application"));
        for (JButton b : new JButton[]{l, r, a, x}) {
            right.add(UI.wide(b));
            right.add(Box.createVerticalStrut(14));
        }
        add(right);

        l.addActionListener(e -> { new LoginFrame(); dispose(); });
        r.addActionListener(e -> { new RegistrationFrame(); dispose(); });
        a.addActionListener(e -> { new AdminLoginFrame(); dispose(); });
        x.addActionListener(e -> System.exit(0));
        UI.apply(this);
        setVisible(true);
    }
}
