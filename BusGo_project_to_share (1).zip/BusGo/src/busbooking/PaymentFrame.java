package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.util.List;
import java.util.UUID;

public class PaymentFrame extends JFrame {
    final int busId;
    final List<Integer> seats;
    final double amount;
    final String seatText;
    JRadioButton upi = new JRadioButton("UPI", true), card = new JRadioButton("Card"), net = new JRadioButton("Net Banking");
    JTextField upiId = new JTextField(), cardNo = new JTextField(), holder = new JTextField(), exp = new JTextField();
    JPasswordField cvv = new JPasswordField();
    JComboBox<String> bank = new JComboBox<>(new String[]{"SBI", "HDFC", "ICICI", "Axis", "Canara", "Indian Bank"});
    CardLayout cl = new CardLayout();
    JPanel cards = new JPanel(cl);

    public PaymentFrame(int busId, List<Integer> seats, double fare) {
        this.busId = busId;
        this.seats = seats;
        this.amount = seats.size() * fare;
        this.seatText = seats.toString().replaceAll("[\\[\\] ]", "");
        setTitle("Payment");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Secure Payment", "Step 3 of 3: review your order and pay"), BorderLayout.NORTH);

        // ---- order summary
        UI.Card sum = new UI.Card();
        sum.setLayout(new BoxLayout(sum, BoxLayout.Y_AXIS));
        sum.setPreferredSize(new Dimension(340, 100));
        sum.add(UI.lbl("ORDER SUMMARY", 12, Font.BOLD, UI.MUTED));
        sum.add(Box.createVerticalStrut(12));
        try (Connection c = DBConnection.getConnection()) {
            PreparedStatement ps = c.prepareStatement("SELECT bus_name,source_city,destination_city,journey_date,departure_time FROM buses WHERE bus_id=?");
            ps.setInt(1, busId);
            ResultSet rs = ps.executeQuery();
            rs.next();
            sum.add(row("Bus", rs.getString(1)));
            sum.add(row("Route", rs.getString(2) + " to " + rs.getString(3)));
            sum.add(row("Date", rs.getString(4)));
            sum.add(row("Departure", rs.getString(5)));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        sum.add(row("Seats", seatText));
        sum.add(row("Fare per seat", "Rs. " + fare));
        sum.add(row("No. of seats", String.valueOf(seats.size())));
        sum.add(Box.createVerticalStrut(10));
        sum.add(UI.lbl("TOTAL PAYABLE", 12, Font.BOLD, UI.MUTED));
        sum.add(UI.lbl("Rs. " + amount, 30, Font.BOLD, UI.ORANGE_DARK));

        // ---- payment methods
        UI.Card pay = new UI.Card();
        pay.setLayout(new BorderLayout(0, 14));
        ButtonGroup bg = new ButtonGroup();
        bg.add(upi); bg.add(card); bg.add(net);
        JPanel methods = new JPanel(new FlowLayout(FlowLayout.LEFT, 18, 0));
        methods.add(upi); methods.add(card); methods.add(net);
        JPanel head = UI.form();
        head.add(UI.lbl("PAYMENT METHOD", 12, Font.BOLD, UI.MUTED));
        head.add(Box.createVerticalStrut(6));
        methods.setAlignmentX(0f);
        head.add(methods);
        pay.add(head, BorderLayout.NORTH);

        JPanel p1 = UI.form();
        UI.field(p1, "UPI ID (example: name@upi)", upiId);
        JPanel p2 = UI.form();
        UI.field(p2, "Card number (16 digits)", cardNo);
        UI.field(p2, "Name on card", holder);
        UI.field(p2, "Expiry (MM/YY)", exp);
        UI.field(p2, "CVV", cvv);
        JPanel p3 = UI.form();
        UI.field(p3, "Select your bank", bank);
        cards.add(p1, "upi"); cards.add(p2, "card"); cards.add(p3, "net");
        cards.setOpaque(false);
        JPanel cardsTop = new JPanel(new BorderLayout());
        cardsTop.add(cards, BorderLayout.NORTH);
        pay.add(cardsTop, BorderLayout.CENTER);
        upi.addActionListener(e -> cl.show(cards, "upi"));
        card.addActionListener(e -> cl.show(cards, "card"));
        net.addActionListener(e -> cl.show(cards, "net"));

        JButton payBtn = new JButton("Pay Rs. " + amount), back = UI.ghost(new JButton("Back"));
        JPanel btns = new JPanel(new GridLayout(1, 2, 12, 0));
        btns.add(back); btns.add(payBtn);
        pay.add(btns, BorderLayout.SOUTH);

        JPanel body = new JPanel(new BorderLayout(20, 0));
        body.setBorder(new EmptyBorder(22, 26, 22, 26));
        body.add(pay, BorderLayout.CENTER);
        body.add(sum, BorderLayout.EAST);
        add(body, BorderLayout.CENTER);

        back.addActionListener(e -> { new SeatSelectionFrame(busId); dispose(); });
        payBtn.addActionListener(e -> pay());
        UI.apply(this);
        setVisible(true);
    }

    JPanel row(String k, String v) {
        JPanel r = new JPanel(new BorderLayout());
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        r.setAlignmentX(0f);
        r.add(UI.lbl(k, 13, Font.PLAIN, UI.MUTED), BorderLayout.WEST);
        r.add(UI.lbl(v, 13, Font.BOLD, UI.NAVY), BorderLayout.EAST);
        return r;
    }

    boolean valid() {
        if (upi.isSelected()) {
            if (!upiId.getText().trim().matches("[\\w.\\-]+@\\w+")) { msg("Enter a valid UPI ID (example: name@upi)"); return false; }
        } else if (card.isSelected()) {
            if (!cardNo.getText().replace(" ", "").matches("\\d{16}")) { msg("Card number must be 16 digits"); return false; }
            if (holder.getText().trim().isEmpty()) { msg("Enter name on card"); return false; }
            if (!exp.getText().trim().matches("(0[1-9]|1[0-2])/\\d{2}")) { msg("Expiry must be MM/YY"); return false; }
            if (!new String(cvv.getPassword()).matches("\\d{3}")) { msg("CVV must be 3 digits"); return false; }
        }
        return true;
    }

    void msg(String s) { JOptionPane.showMessageDialog(this, s); }

    void pay() {
        if (!valid()) return;
        String method = upi.isSelected() ? "UPI" : card.isSelected() ? "CARD" : "NETBANKING";
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                PreparedStatement ps = c.prepareStatement("SELECT seat_numbers FROM bookings WHERE bus_id=? AND status<>'CANCELLED' AND seat_numbers IS NOT NULL FOR UPDATE");
                ps.setInt(1, busId);
                ResultSet rs = ps.executeQuery();
                while (rs.next())
                    for (String s : rs.getString(1).split(","))
                        if (seats.contains(Integer.parseInt(s.trim()))) {
                            c.rollback();
                            msg("Seat " + s.trim() + " was just booked by someone else. Please choose again.");
                            new SeatSelectionFrame(busId);
                            dispose();
                            return;
                        }
                ps = c.prepareStatement("UPDATE buses SET available_seats=available_seats-? WHERE bus_id=? AND available_seats>=?");
                ps.setInt(1, seats.size()); ps.setInt(2, busId); ps.setInt(3, seats.size());
                if (ps.executeUpdate() == 0) throw new Exception("Not enough seats available");
                ps = c.prepareStatement("INSERT INTO bookings(user_id,bus_id,seats,total_fare,seat_numbers) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, Session.userId); ps.setInt(2, busId); ps.setInt(3, seats.size());
                ps.setDouble(4, amount); ps.setString(5, seatText);
                ps.executeUpdate();
                rs = ps.getGeneratedKeys();
                rs.next();
                int id = rs.getInt(1);
                String ref = "TXN" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
                ps = c.prepareStatement("INSERT INTO payments(booking_id,amount,method,txn_ref) VALUES(?,?,?,?)");
                ps.setInt(1, id); ps.setDouble(2, amount); ps.setString(3, method); ps.setString(4, ref);
                ps.executeUpdate();
                c.commit();
                msg("Payment successful!\nTransaction: " + ref + "\nBooking ID: " + id);
                new TicketFrame(id);
                dispose();
            } catch (Exception ex) {
                c.rollback();
                msg("Payment failed: " + ex.getMessage());
            }
        } catch (Exception ex) {
            msg("Error: " + ex.getMessage());
        }
    }
}
