package busbooking;

import javax.swing.*;
import java.awt.*;

public class BookingHistoryFrame extends JFrame {
    public BookingHistoryFrame() {
        setTitle("Booking History");
        setSize(1050, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JTable t = new JTable(DBConnection.table(DBConnection.MY_BOOKINGS, Session.userId));
        JButton back = new JButton("Back");
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(back, BorderLayout.SOUTH);
        back.addActionListener(e -> { new PassengerDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }
}