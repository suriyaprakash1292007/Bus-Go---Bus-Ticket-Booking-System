package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;

public class RegistrationFrame extends JFrame {
    JTextField n = new JTextField(), em = new JTextField(), ph = new JTextField(), u = new JTextField();
    JPasswordField p = new JPasswordField();

    public RegistrationFrame() {
        setTitle("Passenger Registration");
        setSize(980, 720);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        add(UI.hero("Join BusGo", "Create your account and start booking comfortable bus journeys."));

        JPanel right = UI.white();
        right.setBorder(new EmptyBorder(40, 80, 30, 80));
        right.add(UI.h1("Create your account"));
        right.add(Box.createVerticalStrut(4));
        right.add(UI.muted("Passenger ID is generated automatically"));
        right.add(Box.createVerticalStrut(20));
        UI.field(right, "Full name", n);
        UI.field(right, "Email", em);
        UI.field(right, "Phone number", ph);
        UI.field(right, "Username", u);
        UI.field(right, "Password", p);
        JButton reg = new JButton("Register"), back = UI.ghost(new JButton("<  Back to home"));
        right.add(UI.wide(reg));
        right.add(Box.createVerticalStrut(10));
        right.add(UI.wide(back));
        add(right);

        reg.addActionListener(e -> register());
        back.addActionListener(e -> { new MainFrame(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }

    void register() {
        String pw = new String(p.getPassword());
        if (n.getText().trim().isEmpty() || em.getText().trim().isEmpty() || ph.getText().trim().isEmpty()
                || u.getText().trim().isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }
        if (!em.getText().trim().matches(".+@.+\\..+")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address");
            return;
        }
        if (!ph.getText().trim().matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Phone number must be 10 digits");
            return;
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("INSERT INTO users(full_name,email,phone,username,password) VALUES(?,?,?,?,?)")) {
            ps.setString(1, n.getText().trim());
            ps.setString(2, em.getText().trim());
            ps.setString(3, ph.getText().trim());
            ps.setString(4, u.getText().trim());
            ps.setString(5, pw);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
            new LoginFrame();
            dispose();
        } catch (SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(this, "Username already exists. Choose another.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
