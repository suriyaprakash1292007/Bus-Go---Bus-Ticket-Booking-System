package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class BookingFrame extends JFrame {
    JComboBox<String> s = new JComboBox<>(), d = new JComboBox<>();
    JTable t = new JTable();

    public BookingFrame() {
        setTitle("Book Ticket");
        setSize(1150, 680);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Book Ticket", "Step 1 of 3: choose a bus, then pick seats and pay"), BorderLayout.NORTH);
        DBConnection.fillCities(s, d);

        UI.Card filter = new UI.Card();
        filter.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
        JButton search = new JButton("Search Buses");
        filter.add(new JLabel("From")); filter.add(s);
        filter.add(new JLabel("To")); filter.add(d);
        filter.add(search);

        JButton book = new JButton("Select Seats  >"), back = UI.ghost(new JButton("Back"));
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        bottom.add(back); bottom.add(book);

        JPanel body = new JPanel(new BorderLayout(0, 16));
        body.setBorder(new EmptyBorder(18, 24, 16, 24));
        body.add(filter, BorderLayout.NORTH);
        body.add(new JScrollPane(t), BorderLayout.CENTER);
        body.add(bottom, BorderLayout.SOUTH);
        add(body, BorderLayout.CENTER);

        search.addActionListener(e -> t.setModel(DBConnection.table(
                DBConnection.BUS_SQL + " WHERE source_city=? AND destination_city=?", s.getSelectedItem(), d.getSelectedItem())));
        book.addActionListener(e -> book());
        back.addActionListener(e -> { new PassengerDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }

    void book() {
        int r = t.getSelectedRow();
        if (r < 0) {
            JOptionPane.showMessageDialog(this, "Please search and select a bus first");
            return;
        }
        if (Integer.parseInt(t.getValueAt(r, 10).toString()) == 0) {
            JOptionPane.showMessageDialog(this, "This bus is full");
            return;
        }
        new SeatSelectionFrame(Integer.parseInt(t.getValueAt(r, 0).toString()));
        dispose();
    }
}
