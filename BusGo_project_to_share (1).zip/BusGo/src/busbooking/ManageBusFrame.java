package busbooking;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ManageBusFrame extends JFrame {
    String[] names = {"Bus Name", "Bus Number", "Source", "Destination", "Departure", "Arrival", "Date (yyyy-mm-dd)", "Fare", "Total Seats"};
    JTextField[] f = new JTextField[9];
    JTable t = new JTable();

    public ManageBusFrame() {
        setTitle("Manage Buses");
        setSize(1150, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel form = new JPanel(new GridLayout(5, 4, 8, 8)), btn = new JPanel(), south = new JPanel(new BorderLayout());
        for (int i = 0; i < 9; i++) {
            f[i] = new JTextField();
            form.add(new JLabel(names[i]));
            form.add(f[i]);
        }
        JButton addB = new JButton("Add Bus"), updB = new JButton("Update Bus"), delB = new JButton("Delete Bus"), back = new JButton("Back");
        btn.add(addB); btn.add(updB); btn.add(delB); btn.add(back);
        south.add(form, BorderLayout.CENTER);
        south.add(btn, BorderLayout.SOUTH);
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        load();

        t.getSelectionModel().addListSelectionListener(e -> {
            int r = t.getSelectedRow();
            if (r >= 0) for (int i = 0; i < 9; i++) f[i].setText(t.getValueAt(r, i + 1).toString());
        });

        addB.addActionListener(e -> {
            if (empty()) return;
            String[] v = v();
            if (DBConnection.update("INSERT INTO buses(bus_name,bus_number,source_city,destination_city,departure_time,arrival_time,journey_date,fare,total_seats,available_seats) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[8])) {
                load();
                for (JTextField x : f) x.setText("");
            }
        });

        updB.addActionListener(e -> {
            int r = t.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a bus from the table"); return; }
            if (empty()) return;
            String[] v = v();
            if (DBConnection.update("UPDATE buses SET bus_name=?,bus_number=?,source_city=?,destination_city=?,departure_time=?,arrival_time=?,journey_date=?,fare=?,available_seats=available_seats+(?-total_seats),total_seats=? WHERE bus_id=?",
                    v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[8], t.getValueAt(r, 0))) load();
        });

        delB.addActionListener(e -> {
            int r = t.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a bus from the table"); return; }
            Object id = t.getValueAt(r, 0);
            DefaultTableModel m = DBConnection.table("SELECT COUNT(*) FROM bookings WHERE bus_id=? AND status='CONFIRMED'", id);
            if (Integer.parseInt(m.getValueAt(0, 0).toString()) > 0) {
                JOptionPane.showMessageDialog(this, "Cannot delete: this bus has CONFIRMED bookings. Cancel them first.");
                return;
            }
            if (JOptionPane.showConfirmDialog(this, "Delete this bus?") != JOptionPane.YES_OPTION) return;
            DBConnection.update("DELETE FROM bookings WHERE bus_id=?", id);
            if (DBConnection.update("DELETE FROM buses WHERE bus_id=?", id)) load();
        });

        back.addActionListener(e -> { new AdminDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }

    void load() { t.setModel(DBConnection.table(DBConnection.BUS_SQL)); }

    String[] v() {
        String[] s = new String[9];
        for (int i = 0; i < 9; i++) s[i] = f[i].getText().trim();
        return s;
    }

    boolean empty() {
        for (String x : v()) if (x.isEmpty()) { JOptionPane.showMessageDialog(this, "Please fill all fields"); return true; }
        return false;
    }
}