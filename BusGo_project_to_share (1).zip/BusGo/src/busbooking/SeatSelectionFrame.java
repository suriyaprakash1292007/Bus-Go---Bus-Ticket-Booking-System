package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;

public class SeatSelectionFrame extends JFrame {
    static final int MAX_SEATS = 6;
    static final Color BOOKED = new Color(200, 205, 212);
    final int busId;
    double fare;
    final Set<Integer> booked = new HashSet<>();
    final TreeSet<Integer> selected = new TreeSet<>();
    final Map<Integer, JButton> btn = new HashMap<>();
    final JLabel seatsLbl = UI.lbl("None", 15, Font.BOLD, UI.NAVY);
    final JLabel totalLbl = UI.lbl("Rs. 0", 28, Font.BOLD, UI.ORANGE_DARK);
    final JButton proceed = new JButton("Proceed to Payment  >");

    public SeatSelectionFrame(int busId) {
        this.busId = busId;
        setTitle("Select Seats");
        setSize(1000, 740);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        int totalSeats = 40;
        String info = "";
        try (Connection c = DBConnection.getConnection()) {
            PreparedStatement ps = c.prepareStatement("SELECT bus_name,bus_number,source_city,destination_city,journey_date,departure_time,fare,total_seats FROM buses WHERE bus_id=?");
            ps.setInt(1, busId);
            ResultSet rs = ps.executeQuery();
            rs.next();
            fare = rs.getDouble("fare");
            totalSeats = rs.getInt("total_seats");
            info = rs.getString(1) + " (" + rs.getString(2) + ")   |   " + rs.getString(3) + " to " + rs.getString(4)
                    + "   |   " + rs.getString(5) + "  " + rs.getString(6) + "   |   Rs. " + fare + " per seat";
            ps = c.prepareStatement("SELECT seat_numbers FROM bookings WHERE bus_id=? AND status<>'CANCELLED' AND seat_numbers IS NOT NULL");
            ps.setInt(1, busId);
            rs = ps.executeQuery();
            while (rs.next())
                for (String s : rs.getString(1).split(","))
                    if (!s.trim().isEmpty()) booked.add(Integer.parseInt(s.trim()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        add(UI.banner("Select Your Seats", info), BorderLayout.NORTH);

        // ---- seat map card
        UI.Card map = new UI.Card();
        map.setLayout(new BorderLayout(0, 10));
        JPanel grid = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 5);
        JLabel drv = UI.lbl("FRONT  -  DRIVER", 12, Font.BOLD, UI.MUTED);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 5;
        grid.add(drv, g);
        g.gridwidth = 1;
        g.gridx = 2; g.gridy = 1;
        grid.add(Box.createHorizontalStrut(46), g);      // aisle
        for (int n = 1; n <= totalSeats; n++) {
            int col = (n - 1) % 4;
            g.gridy = (n - 1) / 4 + 1;
            g.gridx = col < 2 ? col : col + 1;
            JButton b = new JButton(String.valueOf(n));
            UI.styleButton(b, Color.WHITE, UI.NAVY);
            b.putClientProperty("seat", Boolean.TRUE);
            b.setBorder(new EmptyBorder(0, 0, 0, 0));
            b.setPreferredSize(new Dimension(56, 44));
            btn.put(n, b);
            final int num = n;
            if (booked.contains(n)) b.setEnabled(false);
            else b.addActionListener(e -> toggle(num));
            paint(n);
            grid.add(b, g);
        }
        JScrollPane sp = new JScrollPane(grid);
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.CENTER, 22, 4));
        legend.add(tag("Available", Color.WHITE));
        legend.add(tag("Selected", UI.ORANGE));
        legend.add(tag("Booked", BOOKED));
        map.add(sp, BorderLayout.CENTER);
        map.add(legend, BorderLayout.SOUTH);

        // ---- summary card
        UI.Card sum = new UI.Card();
        sum.setLayout(new BoxLayout(sum, BoxLayout.Y_AXIS));
        sum.setPreferredSize(new Dimension(280, 100));
        sum.add(UI.lbl("YOUR SELECTION", 12, Font.BOLD, UI.MUTED));
        sum.add(Box.createVerticalStrut(8));
        sum.add(seatsLbl);
        sum.add(Box.createVerticalStrut(22));
        sum.add(UI.lbl("Fare per seat", 12, Font.BOLD, UI.MUTED));
        sum.add(UI.lbl("Rs. " + fare, 16, Font.BOLD, UI.NAVY));
        sum.add(Box.createVerticalStrut(22));
        sum.add(UI.lbl("TOTAL", 12, Font.BOLD, UI.MUTED));
        sum.add(totalLbl);
        sum.add(Box.createVerticalStrut(10));
        sum.add(UI.lbl("Maximum " + MAX_SEATS + " seats per booking", 11, Font.PLAIN, UI.MUTED));
        sum.add(Box.createVerticalGlue());
        JButton back = UI.ghost(new JButton("Back"));
        sum.add(UI.wide(proceed));
        sum.add(Box.createVerticalStrut(10));
        sum.add(UI.wide(back));
        proceed.setEnabled(false);

        JPanel body = new JPanel(new BorderLayout(20, 0));
        body.setBorder(new EmptyBorder(20, 24, 20, 24));
        body.add(map, BorderLayout.CENTER);
        body.add(sum, BorderLayout.EAST);
        add(body, BorderLayout.CENTER);

        back.addActionListener(e -> { new BookingFrame(); dispose(); });
        proceed.addActionListener(e -> { new PaymentFrame(busId, new ArrayList<>(selected), fare); dispose(); });
        UI.apply(this);
        sp.setBorder(null);
        sp.getViewport().setOpaque(false);
        sp.setOpaque(false);
        setVisible(true);
    }

    JLabel tag(String t, Color c) {
        JLabel l = new JLabel("  " + t);
        l.setIcon(new Icon() {
            public void paintIcon(Component x, Graphics gr, int a, int b) {
                gr.setColor(c); gr.fillRoundRect(a, b, 18, 18, 6, 6);
                gr.setColor(UI.NAVY); gr.drawRoundRect(a, b, 18, 18, 6, 6);
            }
            public int getIconWidth() { return 19; }
            public int getIconHeight() { return 19; }
        });
        return l;
    }

    void paint(int n) {
        JButton b = btn.get(n);
        if (booked.contains(n)) { b.setBackground(BOOKED); b.setForeground(Color.GRAY); b.putClientProperty("outline", BOOKED); }
        else if (selected.contains(n)) { b.setBackground(UI.ORANGE); b.setForeground(Color.WHITE); b.putClientProperty("outline", UI.ORANGE); }
        else { b.setBackground(Color.WHITE); b.setForeground(UI.NAVY); b.putClientProperty("outline", UI.NAVY); }
        b.repaint();
    }

    void toggle(int n) {
        if (selected.contains(n)) selected.remove(n);
        else {
            if (selected.size() >= MAX_SEATS) {
                JOptionPane.showMessageDialog(this, "You can select maximum " + MAX_SEATS + " seats");
                return;
            }
            selected.add(n);
        }
        paint(n);
        seatsLbl.setText(selected.isEmpty() ? "None" : selected.toString().replaceAll("[\\[\\]]", ""));
        totalLbl.setText("Rs. " + (selected.size() * fare));
        proceed.setEnabled(!selected.isEmpty());
    }
}
