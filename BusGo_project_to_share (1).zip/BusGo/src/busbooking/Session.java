package busbooking;

public class Session {
    public static int userId;
    public static String name;
}