package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PassengerDashboard extends JFrame {
    public PassengerDashboard() {
        setTitle("Passenger Dashboard");
        setSize(900, 640);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Welcome, " + Session.name, "What would you like to do today?"), BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(3, 2, 20, 20));
        grid.setBorder(new EmptyBorder(28, 36, 28, 36));
        String[][] t = {
            {"Search Buses", "Find buses by route"},
            {"View Available Buses", "See seats left on every bus"},
            {"Book Tickets", "Pick a bus, choose seats and pay"},
            {"Booking History", "All your past and current bookings"},
            {"Cancel Tickets", "Cancel a booking and free the seats"},
            {"Logout", "Sign out of your account"}};
        for (String[] s : t) {
            JButton b = new JButton("<html><div style='text-align:center'><span style='font-size:15px'><b>" + s[0]
                    + "</b></span><br><span style='font-size:10px'>" + s[1] + "</span></div></html>");
            if (s[0].equals("Logout")) UI.styleButton(b, UI.RED, Color.WHITE);
            else {
                UI.styleButton(b, Color.WHITE, UI.NAVY);
                b.putClientProperty("outline", UI.LINE);
            }
            grid.add(b);
            b.addActionListener(e -> {
                switch (s[0]) {
                    case "Search Buses":
                    case "View Available Buses": new BusSearchFrame(); break;
                    case "Book Tickets": new BookingFrame(); break;
                    case "Booking History": new BookingHistoryFrame(); break;
                    case "Cancel Tickets": new CancellationFrame(); break;
                    default: Session.userId = 0; new MainFrame();
                }
                dispose();
            });
        }
        add(grid, BorderLayout.CENTER);
        UI.apply(this);
        setVisible(true);
    }
}
