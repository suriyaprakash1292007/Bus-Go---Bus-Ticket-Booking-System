package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class AdminLoginFrame extends JFrame {
    JTextField u = new JTextField();
    JPasswordField p = new JPasswordField();

    public AdminLoginFrame() {
        setTitle("Admin Login");
        setSize(980, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        add(UI.hero("Admin portal", "Manage buses, fares and view every booking in one place."));

        JPanel right = UI.white();
        right.setBorder(new EmptyBorder(100, 80, 40, 80));
        right.add(UI.h1("Admin Login"));
        right.add(Box.createVerticalStrut(4));
        right.add(UI.muted("Authorised staff only"));
        right.add(Box.createVerticalStrut(26));
        UI.field(right, "Admin username", u);
        UI.field(right, "Admin password", p);
        right.add(Box.createVerticalStrut(8));
        JButton login = new JButton("Login"), back = UI.ghost(new JButton("<  Back to home"));
        right.add(UI.wide(login));
        right.add(Box.createVerticalStrut(12));
        right.add(UI.wide(back));
        add(right);

        login.addActionListener(e -> {
            if (DBConnection.table("SELECT admin_id FROM admins WHERE username=? AND password=?",
                    u.getText().trim(), new String(p.getPassword())).getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Invalid admin credentials");
                return;
            }
            new AdminDashboard();
            dispose();
        });
        back.addActionListener(e -> { new MainFrame(); dispose(); });
        UI.apply(this);
        getRootPane().setDefaultButton(login);
        setVisible(true);
    }
}
