package busbooking;

import javax.swing.*;
import java.awt.*;

public class ViewBookingsFrame extends JFrame {
    public ViewBookingsFrame() {
        setTitle("All Bookings");
        setSize(1100, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JTable t = new JTable(DBConnection.table("SELECT b.booking_id `Booking ID`, u.full_name `Passenger Name`, s.bus_name `Bus Name`, s.source_city `Source`, s.destination_city `Destination`, s.journey_date `Journey Date`, b.seats `Seats`, b.total_fare `Total Fare`, b.status `Status` FROM bookings b JOIN users u ON b.user_id=u.user_id JOIN buses s ON b.bus_id=s.bus_id ORDER BY b.booking_id DESC"));
        JButton back = new JButton("Back");
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(back, BorderLayout.SOUTH);
        back.addActionListener(e -> { new AdminDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }
}