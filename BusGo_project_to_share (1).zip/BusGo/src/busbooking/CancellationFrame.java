package busbooking;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class CancellationFrame extends JFrame {
    JTable t = new JTable();

    public CancellationFrame() {
        setTitle("Cancel Ticket");
        setSize(1050, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel p = new JPanel();
        JButton cancel = new JButton("Cancel Selected Booking"), back = new JButton("Back");
        p.add(cancel); p.add(back);
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(p, BorderLayout.SOUTH);
        load();
        cancel.addActionListener(e -> cancel());
        back.addActionListener(e -> { new PassengerDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }

    void load() {
        t.setModel(DBConnection.table(DBConnection.MY_BOOKINGS, Session.userId));
    }

    void cancel() {
        int r = t.getSelectedRow();
        if (r < 0) {
            JOptionPane.showMessageDialog(this, "Select a booking first");
            return;
        }
        int id = Integer.parseInt(t.getValueAt(r, 0).toString());
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                PreparedStatement ps = c.prepareStatement("SELECT bus_id, seats, status FROM bookings WHERE booking_id=? AND user_id=? FOR UPDATE");
                ps.setInt(1, id);
                ps.setInt(2, Session.userId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    c.rollback();
                    JOptionPane.showMessageDialog(this, "Booking not found");
                    return;
                }
                if (rs.getString(3).equals("CANCELLED")) {
                    c.rollback();
                    JOptionPane.showMessageDialog(this, "This booking is already cancelled");
                    return;
                }
                int bus = rs.getInt(1), seats = rs.getInt(2);
                ps = c.prepareStatement("UPDATE bookings SET status='CANCELLED' WHERE booking_id=?");
                ps.setInt(1, id);
                ps.executeUpdate();
                ps = c.prepareStatement("UPDATE buses SET available_seats=available_seats+? WHERE bus_id=?");
                ps.setInt(1, seats);
                ps.setInt(2, bus);
                ps.executeUpdate();
                c.commit();
                JOptionPane.showMessageDialog(this, "Booking cancelled. Seats restored.");
                load();
            } catch (Exception ex) {
                c.rollback();
                JOptionPane.showMessageDialog(this, "Cancellation failed: " + ex.getMessage());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}