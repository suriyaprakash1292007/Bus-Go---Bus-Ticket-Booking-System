package busbooking;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.*;
import java.awt.*;

/** Shared BusGo theme + small helper toolkit used by every frame. */
public class UI {
    public static final Color NAVY = new Color(13, 29, 52);
    public static final Color NAVY_LIGHT = new Color(34, 64, 108);
    public static final Color ORANGE = new Color(245, 151, 20);
    public static final Color ORANGE_DARK = new Color(224, 126, 0);
    public static final Color BG = new Color(243, 246, 251);
    public static final Color WHITE = Color.WHITE;
    public static final Color TEXT = new Color(35, 45, 58);
    public static final Color MUTED = new Color(111, 122, 136);
    public static final Color LINE = new Color(222, 228, 236);
    public static final Color GREEN = new Color(34, 160, 90);
    public static final Color RED = new Color(214, 69, 65);
    static final Font BODY = new Font("Segoe UI", Font.PLAIN, 14);
    static final Font BOLD = new Font("Segoe UI", Font.BOLD, 13);

    private UI() {}

    // ---------------------------------------------------------------- apply
    public static void apply(JFrame f) {
        Container cp = f.getContentPane();
        cp.setBackground(BG);
        f.getRootPane().setBorder(null);
        f.setMinimumSize(new Dimension(520, 380));
        if (cp.getLayout() instanceof BorderLayout) {
            BorderLayout bl = (BorderLayout) cp.getLayout();
            if (bl.getLayoutComponent(BorderLayout.NORTH) == null) {   // old frames: auto banner + padding
                pad(cp, bl, BorderLayout.CENTER);
                pad(cp, bl, BorderLayout.SOUTH);
                cp.add(banner(f.getTitle(), ""), BorderLayout.NORTH);
            }
        }
        style(cp, false);
        cp.revalidate();
        cp.repaint();
    }

    private static void pad(Container cp, BorderLayout bl, String where) {
        Component c = bl.getLayoutComponent(where);
        if (c == null) return;
        cp.remove(c);
        JPanel w = new JPanel(new BorderLayout());
        w.setBorder(new EmptyBorder(14, 20, 10, 20));
        w.add(c);
        cp.add(w, where);
    }

    private static void style(Container parent, boolean overlay) {
        for (Component c : parent.getComponents()) {
            boolean ov = overlay;
            if (c instanceof Card || c instanceof Grad) ov = true;
            if (c instanceof JPanel) {
                JPanel p = (JPanel) c;
                if (ov) p.setOpaque(false);
                else if (p.getClientProperty("keep") == null) p.setBackground(BG);
            }
            if (c instanceof JLabel && ((JLabel) c).getClientProperty("keep") == null) {
                c.setFont(BODY);
                c.setForeground(TEXT);
            }
            if (c instanceof JRadioButton || c instanceof JCheckBox) {
                c.setFont(BODY);
                c.setForeground(TEXT);
                ((JComponent) c).setOpaque(false);
            } else if (c instanceof AbstractButton && ((AbstractButton) c).getClientProperty("styled") == null) {
                styleButton((AbstractButton) c, ORANGE, Color.WHITE);
            }
            if (c instanceof JTextField) {          // also covers JPasswordField
                c.setFont(BODY);
                c.setForeground(TEXT);
                c.setBackground(WHITE);
                ((JComponent) c).setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(8, 10, 8, 10)));
                c.setPreferredSize(new Dimension(160, 40));
            }
            if (c instanceof JComboBox) {
                c.setFont(BODY);
                c.setBackground(WHITE);
                c.setForeground(TEXT);
                ((JComponent) c).setBorder(new LineBorder(LINE, 1, true));
                c.setPreferredSize(new Dimension(160, 38));
            }
            if (c instanceof JSpinner) {
                c.setFont(BODY);
                c.setPreferredSize(new Dimension(75, 38));
            }
            if (c instanceof JTable) styleTable((JTable) c);
            if (c instanceof JScrollPane) {
                ((JScrollPane) c).setBorder(new LineBorder(LINE, 1, true));
                ((JScrollPane) c).getViewport().setBackground(WHITE);
            }
            if (c instanceof Container) style((Container) c, ov);
        }
    }

    private static void styleTable(JTable t) {
        t.setFont(BODY);
        t.setForeground(TEXT);
        t.setBackground(WHITE);
        t.setRowHeight(36);
        t.setShowVerticalLines(false);
        t.setGridColor(new Color(235, 238, 242));
        t.setSelectionBackground(new Color(255, 232, 196));
        t.setSelectionForeground(NAVY);
        t.setFillsViewportHeight(true);
        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(tb, v, sel, false, row, col);
                setHorizontalAlignment(LEFT);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                if (!sel) setBackground(row % 2 == 0 ? WHITE : new Color(247, 249, 252));
                return this;
            }
        };
        t.setDefaultRenderer(Object.class, r);
        t.setDefaultRenderer(Number.class, r);
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(h.getPreferredSize().width, 42));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int row, int col) {
                super.getTableCellRendererComponent(tb, v, false, false, row, col);
                setBackground(NAVY);
                setForeground(Color.WHITE);
                setFont(BOLD);
                setOpaque(true);
                setHorizontalAlignment(LEFT);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });
    }

    // -------------------------------------------------------------- buttons
    public static <T extends AbstractButton> T styleButton(T b, Color bg, Color fg) {
        b.setUI(new RoundUI());
        b.setBackground(bg);
        b.setForeground(fg);
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setRolloverEnabled(true);
        b.setFont(BOLD);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(11, 20, 11, 20));
        b.putClientProperty("styled", Boolean.TRUE);
        return b;
    }

    public static JButton ghost(JButton b) {          // white button with navy outline
        styleButton(b, WHITE, NAVY);
        b.putClientProperty("outline", NAVY);
        return b;
    }

    public static JButton danger(JButton b) { return styleButton(b, RED, Color.WHITE); }

    static class RoundUI extends BasicButtonUI {
        public void paint(Graphics g, JComponent c) {
            AbstractButton b = (AbstractButton) c;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color bg = b.getBackground();
            boolean seat = b.getClientProperty("seat") != null;
            if (!b.isEnabled() && !seat) bg = new Color(205, 210, 218);
            else if (b.isEnabled() && b.getModel().isRollover()) bg = new Color(Math.max(0, bg.getRed() - 18), Math.max(0, bg.getGreen() - 18), Math.max(0, bg.getBlue() - 18));
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
            Object o = b.getClientProperty("outline");
            if (o instanceof Color) {
                g2.setColor((Color) o);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
            }
            g2.dispose();
            super.paint(g, c);
        }
    }

    // ---------------------------------------------------------- containers
    public static class Grad extends JPanel {
        Color a, b;
        boolean accent;
        Grad(Color a, Color b) { this.a = a; this.b = b; setOpaque(false); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setPaint(new GradientPaint(0, 0, a, getWidth(), getHeight(), b));
            g2.fillRect(0, 0, getWidth(), getHeight());
            if (accent) { g2.setColor(ORANGE); g2.fillRect(0, getHeight() - 4, getWidth(), 4); }
            g2.dispose();
        }
    }

    public static class Card extends JPanel {
        public Card() { setOpaque(false); setBorder(new EmptyBorder(18, 20, 22, 24)); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth() - 4, h = getHeight() - 4;
            g2.setColor(new Color(0, 0, 0, 16));
            g2.fillRoundRect(2, 3, w, h, 18, 18);
            g2.setColor(WHITE);
            g2.fillRoundRect(0, 0, w, h, 18, 18);
            g2.setColor(LINE);
            g2.drawRoundRect(0, 0, w, h, 18, 18);
            g2.dispose();
        }
    }

    static class BusIcon extends JComponent {
        BusIcon() {
            setPreferredSize(new Dimension(240, 100));
            setMaximumSize(new Dimension(240, 100));
            setAlignmentX(CENTER_ALIGNMENT);
        }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int x = 20, y = 10;
            g2.setColor(ORANGE);
            g2.fillRoundRect(x, y, 200, 62, 22, 22);
            g2.setColor(new Color(205, 232, 255));
            for (int i = 0; i < 5; i++) g2.fillRoundRect(x + 14 + i * 34, y + 12, 26, 20, 6, 6);
            g2.setColor(Color.WHITE);
            g2.fillRect(x + 10, y + 42, 180, 4);
            g2.setColor(new Color(8, 14, 26));
            g2.fillOval(x + 30, y + 48, 30, 30);
            g2.fillOval(x + 140, y + 48, 30, 30);
            g2.setColor(new Color(190, 198, 210));
            g2.fillOval(x + 39, y + 57, 12, 12);
            g2.fillOval(x + 149, y + 57, 12, 12);
            g2.dispose();
        }
    }

    // ------------------------------------------------------------- helpers
    public static JPanel banner(String title, String sub) {
        Grad g = new Grad(NAVY, NAVY_LIGHT);
        g.accent = true;
        g.setLayout(new BoxLayout(g, BoxLayout.Y_AXIS));
        g.setBorder(new EmptyBorder(18, 28, 22, 28));
        g.add(lbl(title, 24, Font.BOLD, Color.WHITE));
        if (sub != null && !sub.isEmpty()) {
            g.add(Box.createVerticalStrut(4));
            g.add(lbl(sub, 13, Font.PLAIN, new Color(205, 218, 235)));
        }
        return g;
    }

    public static JPanel hero(String big, String small) {
        Grad g = new Grad(NAVY, NAVY_LIGHT);
        g.setLayout(new BoxLayout(g, BoxLayout.Y_AXIS));
        g.setBorder(new EmptyBorder(30, 36, 30, 36));
        g.add(Box.createVerticalGlue());
        g.add(new BusIcon());
        g.add(Box.createVerticalStrut(10));
        JLabel brand = lbl("<html>Bus<font color='#F59714'>Go</font></html>", 40, Font.BOLD, Color.WHITE);
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);
        g.add(brand);
        g.add(Box.createVerticalStrut(18));
        JLabel b = lbl(big, 24, Font.BOLD, Color.WHITE);
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        g.add(b);
        g.add(Box.createVerticalStrut(8));
        JLabel s = lbl("<html><div style='text-align:center;width:260px'>" + small + "</div></html>", 13, Font.PLAIN, new Color(205, 218, 235));
        s.setAlignmentX(Component.CENTER_ALIGNMENT);
        g.add(s);
        g.add(Box.createVerticalGlue());
        return g;
    }

    public static JLabel lbl(String t, int size, int style, Color c) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Segoe UI", style, size));
        l.setForeground(c);
        l.putClientProperty("keep", Boolean.TRUE);
        return l;
    }

    public static JLabel h1(String t) { JLabel l = lbl(t, 28, Font.BOLD, NAVY); l.setAlignmentX(0f); return l; }
    public static JLabel muted(String t) { JLabel l = lbl(t, 13, Font.PLAIN, MUTED); l.setAlignmentX(0f); return l; }
    public static JLabel heading(String t) { return lbl(t, 20, Font.BOLD, NAVY); }

    public static JPanel form() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        return p;
    }

    public static JPanel white() {                 // plain white panel
        JPanel p = form();
        p.setOpaque(true);
        p.setBackground(WHITE);
        p.putClientProperty("keep", Boolean.TRUE);
        return p;
    }

    public static void field(JPanel p, String label, JComponent c) {
        JLabel l = lbl(label, 12, Font.BOLD, MUTED);
        l.setAlignmentX(0f);
        p.add(l);
        p.add(Box.createVerticalStrut(4));
        p.add(wide(c, 40));
        p.add(Box.createVerticalStrut(12));
    }

    public static <T extends JComponent> T wide(T c, int h) {
        c.setAlignmentX(0f);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, h));
        return c;
    }

    public static JButton wide(JButton b) {
        b.setAlignmentX(0f);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        return b;
    }
}
