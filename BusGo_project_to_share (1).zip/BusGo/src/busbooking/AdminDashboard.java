package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminDashboard extends JFrame {
    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(1000, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Admin Dashboard", "Buses, bookings and seats at a glance"), BorderLayout.NORTH);

        DefaultTableModel m = DBConnection.table("SELECT (SELECT COUNT(*) FROM buses), (SELECT COUNT(*) FROM bookings), (SELECT COUNT(*) FROM bookings WHERE status='CONFIRMED'), (SELECT COUNT(*) FROM bookings WHERE status='CANCELLED'), (SELECT IFNULL(SUM(available_seats),0) FROM buses)");
        String[] names = {"Total Buses", "Total Bookings", "Confirmed", "Cancelled", "Available Seats"};
        Color[] cols = {UI.NAVY, UI.NAVY_LIGHT, UI.GREEN, UI.RED, UI.ORANGE_DARK};
        JPanel stats = new JPanel(new GridLayout(1, 5, 16, 0));
        for (int i = 0; i < 5; i++) {
            UI.Card c = new UI.Card();
            c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
            JLabel v = UI.lbl(String.valueOf(m.getRowCount() > 0 ? m.getValueAt(0, i) : 0), 34, Font.BOLD, cols[i]);
            c.add(v);
            c.add(UI.lbl(names[i], 13, Font.PLAIN, UI.MUTED));
            stats.add(c);
        }
        JButton mb = new JButton("Manage Buses"), vb = UI.ghost(new JButton("View All Bookings")), lo = UI.danger(new JButton("Logout"));
        JPanel actions = new JPanel(new GridLayout(1, 3, 16, 0));
        actions.setPreferredSize(new Dimension(100, 56));
        actions.add(mb); actions.add(vb); actions.add(lo);

        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setBorder(new EmptyBorder(28, 30, 28, 30));
        body.add(stats, BorderLayout.NORTH);
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.add(actions, BorderLayout.NORTH);
        body.add(wrap, BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);

        mb.addActionListener(e -> { new ManageBusFrame(); dispose(); });
        vb.addActionListener(e -> { new ViewBookingsFrame(); dispose(); });
        lo.addActionListener(e -> { new MainFrame(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }
}
