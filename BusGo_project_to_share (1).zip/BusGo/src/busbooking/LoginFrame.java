package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LoginFrame extends JFrame {
    JTextField u = new JTextField();
    JPasswordField p = new JPasswordField();

    public LoginFrame() {
        setTitle("Passenger Login");
        setSize(980, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        add(UI.hero("Welcome back", "Login to pick your bus, choose your seat and get your ticket."));

        JPanel right = UI.white();
        right.setBorder(new EmptyBorder(90, 80, 40, 80));
        right.add(UI.h1("Login"));
        right.add(Box.createVerticalStrut(4));
        right.add(UI.muted("Enter your account details"));
        right.add(Box.createVerticalStrut(26));
        UI.field(right, "Username", u);
        UI.field(right, "Password", p);
        right.add(Box.createVerticalStrut(8));
        JButton login = new JButton("Login"), reg = UI.ghost(new JButton("Create new account")), back = UI.ghost(new JButton("<  Back to home"));
        right.add(UI.wide(login));
        right.add(Box.createVerticalStrut(12));
        right.add(UI.wide(reg));
        right.add(Box.createVerticalStrut(12));
        right.add(UI.wide(back));
        add(right);

        login.addActionListener(e -> {
            DefaultTableModel m = DBConnection.table("SELECT user_id, full_name FROM users WHERE username=? AND password=?",
                    u.getText().trim(), new String(p.getPassword()));
            if (m.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Invalid username or password");
                return;
            }
            Session.userId = Integer.parseInt(m.getValueAt(0, 0).toString());
            Session.name = m.getValueAt(0, 1).toString();
            new PassengerDashboard();
            dispose();
        });
        reg.addActionListener(e -> { new RegistrationFrame(); dispose(); });
        back.addActionListener(e -> { new MainFrame(); dispose(); });
        UI.apply(this);
        getRootPane().setDefaultButton(login);
        setVisible(true);
    }
}
