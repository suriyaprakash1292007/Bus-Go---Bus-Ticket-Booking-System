package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.*;
import java.util.Random;

public class TicketFrame extends JFrame {
    public TicketFrame(int id) {
        setTitle("Ticket");
        setSize(700, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Booking Confirmed", "Show this ticket at the boarding point"), BorderLayout.NORTH);

        DefaultTableModel m = DBConnection.table("SELECT b.booking_id, u.full_name, s.bus_name, s.bus_number, s.source_city, s.destination_city, s.journey_date, s.departure_time, b.seats, b.seat_numbers, b.total_fare, b.status FROM bookings b JOIN users u ON b.user_id=u.user_id JOIN buses s ON b.bus_id=s.bus_id WHERE b.booking_id=?", id);
        String[] v = new String[12];
        for (int i = 0; i < 12; i++) v[i] = m.getRowCount() > 0 ? String.valueOf(m.getValueAt(0, i)) : "-";

        UI.Card card = new UI.Card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(24, 30, 28, 34));
        JPanel top = new JPanel(new BorderLayout());
        top.setAlignmentX(0f);
        top.add(UI.lbl(v[2], 24, Font.BOLD, UI.NAVY), BorderLayout.WEST);
        JLabel chip = UI.lbl("  " + v[11] + "  ", 12, Font.BOLD, UI.GREEN);
        chip.setOpaque(true);
        chip.setBackground(new Color(220, 245, 230));
        top.add(chip, BorderLayout.EAST);
        card.add(top);
        JLabel route = UI.lbl(v[4] + "  to  " + v[5], 16, Font.BOLD, UI.ORANGE_DARK);
        route.setAlignmentX(0f);
        card.add(Box.createVerticalStrut(6));
        card.add(route);
        card.add(Box.createVerticalStrut(16));
        card.add(new Dash());
        card.add(Box.createVerticalStrut(14));
        String[][] rows = {{"Booking ID", "#" + v[0]}, {"Passenger", v[1]}, {"Bus number", v[3]}, {"Journey date", v[6]},
            {"Departure", v[7]}, {"No. of seats", v[8]}, {"Seat numbers", v[9]}, {"Total paid", "Rs. " + v[10]}};
        for (String[] r : rows) {
            JPanel p = new JPanel(new BorderLayout());
            p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
            p.setAlignmentX(0f);
            p.add(UI.lbl(r[0], 14, Font.PLAIN, UI.MUTED), BorderLayout.WEST);
            boolean tot = r[0].equals("Total paid");
            p.add(UI.lbl(r[1], tot ? 17 : 14, Font.BOLD, tot ? UI.ORANGE_DARK : UI.NAVY), BorderLayout.EAST);
            card.add(p);
        }
        card.add(Box.createVerticalStrut(10));
        card.add(new Dash());
        card.add(Box.createVerticalStrut(14));
        card.add(new Barcode(id));

        JButton pr = new JButton("Print Ticket"), bk = UI.ghost(new JButton("Back to Dashboard"));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        btns.add(bk); btns.add(pr);

        JPanel body = new JPanel(new BorderLayout(0, 16));
        body.setBorder(new EmptyBorder(20, 60, 18, 60));
        body.add(card, BorderLayout.CENTER);
        body.add(btns, BorderLayout.SOUTH);
        add(body, BorderLayout.CENTER);

        pr.addActionListener(e -> {
            try {
                PrinterJob job = PrinterJob.getPrinterJob();
                job.setPrintable((g, pf, page) -> {
                    if (page > 0) return Printable.NO_SUCH_PAGE;
                    Graphics2D g2 = (Graphics2D) g;
                    g2.translate(pf.getImageableX(), pf.getImageableY());
                    card.printAll(g2);
                    return Printable.PAGE_EXISTS;
                });
                if (job.printDialog()) job.print();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Print error: " + ex.getMessage());
            }
        });
        bk.addActionListener(e -> { new PassengerDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }

    static class Dash extends JComponent {
        Dash() { setPreferredSize(new Dimension(100, 2)); setMaximumSize(new Dimension(Integer.MAX_VALUE, 2)); setAlignmentX(0f); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(UI.LINE);
            g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{6f, 6f}, 0f));
            g2.drawLine(0, 1, getWidth(), 1);
            g2.dispose();
        }
    }

    static class Barcode extends JComponent {
        final int seed;
        Barcode(int seed) { this.seed = seed; setPreferredSize(new Dimension(100, 60)); setMaximumSize(new Dimension(Integer.MAX_VALUE, 60)); setAlignmentX(0f); }
        protected void paintComponent(Graphics g) {
            Random r = new Random(seed * 7919L);
            g.setColor(UI.NAVY);
            int x = 0;
            while (x < getWidth()) {
                int w = 1 + r.nextInt(4);
                g.fillRect(x, 0, w, getHeight());
                x += w + 1 + r.nextInt(4);
            }
        }
    }
}
