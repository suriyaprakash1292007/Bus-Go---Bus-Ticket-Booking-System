package busbooking;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class BusSearchFrame extends JFrame {
    JComboBox<String> s = new JComboBox<>(), d = new JComboBox<>();
    JTable t = new JTable();
    JLabel info = new JLabel("Select a bus to see seat details");

    public BusSearchFrame() {
        setTitle("Search Buses");
        setSize(1150, 680);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(UI.banner("Search Buses", "Find buses by route and check seat availability"), BorderLayout.NORTH);
        DBConnection.fillCities(s, d);

        UI.Card filter = new UI.Card();
        filter.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
        JButton search = new JButton("Search"), back = UI.ghost(new JButton("Back"));
        filter.add(new JLabel("From")); filter.add(s);
        filter.add(new JLabel("To")); filter.add(d);
        filter.add(search); filter.add(back);

        JPanel body = new JPanel(new BorderLayout(0, 16));
        body.setBorder(new EmptyBorder(18, 24, 16, 24));
        body.add(filter, BorderLayout.NORTH);
        body.add(new JScrollPane(t), BorderLayout.CENTER);
        body.add(info, BorderLayout.SOUTH);
        add(body, BorderLayout.CENTER);

        t.setModel(DBConnection.table(DBConnection.BUS_SQL + " WHERE available_seats>0"));
        search.addActionListener(e -> t.setModel(DBConnection.table(
                DBConnection.BUS_SQL + " WHERE source_city=? AND destination_city=?", s.getSelectedItem(), d.getSelectedItem())));
        t.getSelectionModel().addListSelectionListener(e -> {
            int r = t.getSelectedRow();
            if (r >= 0) {
                int total = Integer.parseInt(t.getValueAt(r, 9).toString());
                int avail = Integer.parseInt(t.getValueAt(r, 10).toString());
                info.setText("Total seats: " + total + "   |   Booked: " + (total - avail) + "   |   Available: " + avail);
            }
        });
        back.addActionListener(e -> { new PassengerDashboard(); dispose(); });
        UI.apply(this);
        setVisible(true);
    }
}
