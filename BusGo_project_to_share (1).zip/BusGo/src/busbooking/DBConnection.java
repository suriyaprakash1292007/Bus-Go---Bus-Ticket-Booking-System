package busbooking;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DBConnection {
    static final String URL = "jdbc:mysql://localhost:3306/busbooking?useSSL=false&allowPublicKeyRetrieval=true";
    static final String USER = "root";
    static final String PASS = "root";

    public static final String BUS_SQL = "SELECT bus_id `Bus ID`, bus_name `Bus Name`, bus_number `Bus Number`, source_city `Source`, destination_city `Destination`, departure_time `Departure`, arrival_time `Arrival`, journey_date `Journey Date`, fare `Fare`, total_seats `Total Seats`, available_seats `Available Seats` FROM buses";

    public static final String MY_BOOKINGS = "SELECT b.booking_id `Booking ID`, s.bus_name `Bus Name`, s.source_city `Source`, s.destination_city `Destination`, s.journey_date `Journey Date`, b.seats `Seats`, b.total_fare `Total Fare`, b.status `Status` FROM bookings b JOIN buses s ON b.bus_id=s.bus_id WHERE b.user_id=? ORDER BY b.booking_id DESC";

    // Reusable connection
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            return null;
        }
    }

    // Runs a SELECT and returns a table model (used for JTable and for checks)
    public static DefaultTableModel table(String sql, Object... p) {
        DefaultTableModel m = new DefaultTableModel() {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < p.length; i++) ps.setObject(i + 1, p[i]);
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();
            for (int i = 1; i <= n; i++) m.addColumn(md.getColumnLabel(i));
            while (rs.next()) {
                Object[] row = new Object[n];
                for (int i = 0; i < n; i++) row[i] = rs.getObject(i + 1);
                m.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return m;
    }

    // Runs INSERT / UPDATE / DELETE
    public static boolean update(String sql, Object... p) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < p.length; i++) ps.setObject(i + 1, p[i]);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            return false;
        }
    }

    // Fills the Source and Destination combo boxes
    public static void fillCities(JComboBox<String> a, JComboBox<String> b) {
        DefaultTableModel m = table("SELECT source_city FROM buses UNION SELECT destination_city FROM buses");
        for (int i = 0; i < m.getRowCount(); i++) {
            a.addItem(m.getValueAt(i, 0).toString());
            b.addItem(m.getValueAt(i, 0).toString());
        }
        if (b.getItemCount() > 1) b.setSelectedIndex(1);
    }
}